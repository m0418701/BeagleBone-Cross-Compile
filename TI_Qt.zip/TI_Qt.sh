echo $QMAKESPEC
source /opt/ti-processor-sdk-linux-am57xx-evm-06.03.00.106/linux-devkit/environment-setup
echo $QMAKESPEC
/opt/Qt5.14.2/Tools/QtCreator/bin/qtcreator
